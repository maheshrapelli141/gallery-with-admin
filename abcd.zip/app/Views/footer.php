</div>

	<!-- jQuery -->
	<script src="/assets/js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="/assets/js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="/assets/js/bootstrap.min.js"></script>
	<!-- Carousel -->
	<script src="/assets/js/owl.carousel.min.js"></script>
	<!-- Stellar -->
	<script src="/assets/js/jquery.stellar.min.js"></script>
	<!-- Waypoints -->
	<script src="/assets/js/jquery.waypoints.min.js"></script>
	<!-- Counters -->
	<script src="/assets/js/jquery.countTo.js"></script>
	
	
	<!-- MAIN JS -->
	<script src="/assets/js/main.js"></script>

	</body>
</html>


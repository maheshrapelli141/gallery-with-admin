

		<div id="fh5co-main">

			

			<div class="fh5co-narrow-content animate-box fh5co-border-bottom" data-animate-effect="fadeInLeft">
				<h2 class="fh5co-heading" >Nature</span></h2>
				<p><p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.</p></p>

				<div class="row">
					<div class="col-md-12">
						<figure><img src="images/big_1.jpg" alt="Free HTML5 Bootstrap Template by FreeHTML5.co" class="img-responsive"></figure>
					</div>

					<div class="col-md-12">
						<figure><img src="images/big_2.jpg" alt="Free HTML5 Bootstrap Template by FreeHTML5.co" class="img-responsive">
							<figcaption>An image caption, pointing has no <a href="#">control</a> about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.</figcaption>
						</figure>
					</div>
					<div class="col-md-12">
						<figure><img src="images/big_3.jpg" alt="Free HTML5 Bootstrap Template by FreeHTML5.co" class="img-responsive"></figure>
					</div>
					<div class="col-md-12">
					<p class="text-center"><a href="portfolio.html" class="btn btn-primary btn-outline">More Photos</a></p>
					</div>
					
				</div>

			</div>


			<div class="fh5co-narrow-content">
				<div class="row">
					<div class="col-md-4 animate-box" data-animate-effect="fadeInLeft">
						<h1 class="fh5co-heading-colored">Get in touch</h1>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
						<p class="fh5co-lead">Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
						<p><a href="#" class="btn btn-primary">Learn More</a></p>
					</div>
					
				</div>
			</div>

		</div>